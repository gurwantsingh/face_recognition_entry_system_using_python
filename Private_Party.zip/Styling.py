# +++++    BOOKS MANAGER PAGE     +++++

from tkinter import *
from tkinter import ttk




class viewBooks:
    def __init__(self):
        self.root = Tk()
        self.root.geometry('650x550')
        self.root.title('BOOK MANAGEMENT')
        self.root.state('zoomed')  # to make the root window occupy all the screen
        self.root.config(background='#4b4e6d') #TO CHANGE THE BACKGROUND COLOR

        # _____  Title Frame  _____


        # fg='#xxxxxxx' - to change the font color
        # bg='#xxxxxxx' - to change the Background color
        self.TitleFrame = Frame(self.root, bg='#4b4e6d')
        self.TitleFrame.pack()

        self.title = Label(self.TitleFrame, text='PUBLISHED BOOKS', font=('Constantia', 35), padx=10, pady=15,
                           fg='#e8ebed',
                           bg='#4b4e6d')
        self.title.pack(side=LEFT, padx=110, anchor='w')

        self.dateLabel = Button(self.TitleFrame, text='Filter by date', font=('Constantia', 11),
                                bg='#e8ebed')
        self.dateLabel.pack(side=RIGHT, anchor='e')

        self.yearList()

        # for combobox, only font and width will work to change its dimensions
        self.dateEntry = ttk.Combobox(self.TitleFrame, font=('Constantia', 16), state="readonly", justify='left', height=20, values=self.years)
        self.dateEntry.pack(side=RIGHT, anchor='e')


        # _____  TreeView  _____
        self.table = ttk.Treeview(self.root)
        self.table['column'] = ('b_id', 'b_name', 'b_publisher', 'b_year', 'b_isbn', 't_name')

        self.table.column('#0', width=0)
        self.table.column('b_id', width=100, anchor=CENTER)
        self.table.column('b_name', width=250, anchor=W)
        self.table.column('b_publisher', width=250, anchor=W)
        self.table.column('b_year', width=100, anchor=W)
        self.table.column('b_isbn', width=100, anchor=CENTER)
        self.table.column('t_name', width=100, anchor=CENTER)

        self.table.heading('b_id', text='ID', anchor=CENTER)
        self.table.heading('b_name', text='NAME', anchor=W)
        self.table.heading('b_publisher', text='PUBLISHER', anchor=W)
        self.table.heading('b_year', text='YEAR', anchor=W)
        self.table.heading('b_isbn', text='ISBN', anchor=CENTER)
        self.table.heading('t_name', text='TEACHER', anchor=CENTER)


        self.table['show'] = 'headings'
        self.table.pack(pady=20)

        # ____TREE VIEW ITEM ENTRY____

        self.table.insert('', index=0, values=['sh', 'jbdej', 'hcvdw', 'cbuehcu'])
        self.table.insert('', index=1, values=['sh', 'jbdej', 'hcvdw', 'cbuehcu'])

        # ____TREE VIEW STYLING ____
        self.treeStyle = ttk.Style()
        self.treeStyle.configure('Treeview', background='#e8ebed', foreground='#e8ebed', rowheight=45,
                                 )
        self.treeStyle.map('Treeview', background=[('selected', '#84dcc6')])

        # HIGHLIGHTBACKGROUND = BORDER COLOR
        # HIGHLIGHTTHICKNESS = BORDER WIDTH

        # example of padding within the element and its internal content(padding while declaratiion)
        self.buttonFrame = Frame(self.root, bg='#4b4e6d', highlightbackground='#e8ebed',
                               highlightthickness=3, pady=20, padx=20)
        self.buttonFrame.pack()

        self.generateReport = Button(self.buttonFrame, text='EXPORT CSV', font=('Constantia', 14), width=15,
                                 pady=2, activebackground='#BFC1C5')

        # activebackground = background color of a btn when it is pressed
        # activeforeground = Font color of a btn when it is pressed
        self.exitButton = Button(self.buttonFrame, text='EXIT', font=('Constantia', 14), width=15,
                                 command=self.leave, pady=5, bg='#40c9a7', activebackground='#288f76', activeforeground='white')
        self.refreshButton = Button(self.buttonFrame, text='REFRESH', font=('Constantia', 14), width=15,
                                     pady=2, activebackground='#BFC1C5')

        # example of padding between 2 elements (padding while pack or grid)
        self.generateReport.grid(row=0, column=0, padx=30)
        self.exitButton.grid(row=0, column=2, padx=20)
        self.refreshButton.grid(row=0, column=1, padx=30)

        self.root.mainloop()



    def leave(self):
        self.root.destroy()



    def yearList(self):
        self.years = []
        for i in range(1970, 2031):
            self.years.append(i)





viewBooks()